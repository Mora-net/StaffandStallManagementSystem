--- Stall's information ---
--- function SearchByName
CREATE FUNCTION fn_SearchStallByName
(
    @Keyword VARCHAR(50)
)
RETURNS TABLE
AS
RETURN
(
    SELECT *
    FROM tbStall
    WHERE StallTypeName like @Keyword + '%'
);
GO
--- UpdateStall
CREATE PROCEDURE sp_UpdateStall
    @StallNo SMALLINT,
    @StallTypeID TINYINT,
    @Status BIT,
    @StallTypeName VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE tbStall
    SET 
        StallTypeID = @StallTypeID,
        Status = @Status,
        StallTypeName = @StallTypeName
    WHERE 
        StallNo = @StallNo;
END;
GO
--- StallById
CREATE PROCEDURE sp_GetStallById
    @StallNo SMALLINT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT *
    FROM tbStall
    WHERE StallNo = @StallNo;
END;
GO
--- InsertStall
CREATE PROCEDURE sp_InsertStall
    @StallNo SMALLINT,
    @StallTypeID TINYINT,
    @Status BIT,
    @StallTypeName VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO tbStall (StallNo, StallTypeID, Status, StallTypeName)
    VALUES (@StallNo, @StallTypeID, @Status, @StallTypeName);
END;
GO
--- SearchByName
CREATE PROCEDURE sp_SearchStallByName
    @Name VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT *
    FROM tbStall
    WHERE StallTypeName LIKE  @Name + '%';
END;
GO
--- View Stall Pirce
CREATE VIEW vw_StallWithPrice AS
SELECT 
    s.StallNo,
    t.UnitPrice
FROM 
    tbStall s
JOIN 
    tbStallType t ON s.StallTypeID = t.StallTypeID;
END
Go




