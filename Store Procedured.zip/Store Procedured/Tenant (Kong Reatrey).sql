--- Tenant Information ---
--- function SearchTenantByName
CREATE FUNCTION fn_SearchTenantByName
(
  @Name VARCHAR(100)
)
RETURNS TABLE
AS
RETURN
(
  SELECT 
    TenantID,
    FirstName + ' ' + LastName AS FullName
  FROM 
    tbTenant
  WHERE 
    FirstName + ' ' + LastName LIKE  @Name + '%'
);
END
Go
--- UpdateTenant
CREATE PROCEDURE sp_UpdateTenant
    @TenantID INT,
    @FirstName VARCHAR(50),
    @LastName VARCHAR(50),
    @Sex VARCHAR(6),
    @HouseNo VARCHAR(20),
    @StreetNo VARCHAR(20),
    @Sangkat VARCHAR(100),
    @Khann VARCHAR(100),
    @City VARCHAR(100),
    @PhoneNumber VARCHAR(100)
AS
BEGIN
    UPDATE tbTenant
    SET 
        FirstName = @FirstName,
        LastName = @LastName,
        Sex = @Sex,
        HouseNo = @HouseNo,
        StreetNo = @StreetNo,
        Sangkat = @Sangkat,
        Khann = @Khann,
        City = @City,
        PhoneNumber = @PhoneNumber
    WHERE 
        TenantID = @TenantID;
END;
Go
--- CountTenants
CREATE PROCEDURE usp_CountTenants
AS
BEGIN
    SELECT COUNT(TenantID) AS TotalTenants 
    FROM tbTenant;
END;
Go
--- InsertTenant
CREATE PROCEDURE usp_InsertTenant
    @FirstName VARCHAR(50),
    @LastName VARCHAR(50),
    @Sex VARCHAR(6),
    @HouseNo VARCHAR(20),
    @StreetNo VARCHAR(20),
    @Sangkat VARCHAR(100),
    @Khann VARCHAR(100),
    @City VARCHAR(100),
    @PhoneNumber VARCHAR(100)
AS
BEGIN
    INSERT INTO tbTenant (
        FirstName,
        LastName,
        Sex,
        HouseNo,
        StreetNo,
        Sangkat,
        Khann,
        City,
        PhoneNumber
    )
    VALUES (
        @FirstName,
        @LastName,
        @Sex,
        @HouseNo,
        @StreetNo,
        @Sangkat,
        @Khann,
        @City,
        @PhoneNumber
    );
END;
Go
--- GetTenantById
CREATE PROCEDURE GetTenantByID
    @TenantID INT
AS
BEGIN
    SELECT * FROM tbTenant WHERE TenantID = @TenantID;
END;
Go




