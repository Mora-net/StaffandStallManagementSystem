--- User's Information ---
--- fucntion Count Users
CREATE FUNCTION fn_CountUsers()
RETURNS INT
AS
BEGIN
    DECLARE @TotalUsers INT;

    SELECT @TotalUsers = COUNT(*) FROM tbUser;

    RETURN @TotalUsers;
END;
Go
--- InsertUsers
CREATE PROCEDURE InsertUser
    @UserID smallint,
    @UserName varchar(50),
    @Password varchar(50),
    @StaffID smallint,
    @StaffNameEN varchar(35),
    @StaffNameKH nvarchar(35),
    @StaffPosition varchar(50)
AS
BEGIN
    INSERT INTO tbUser (
        UserID,
        UserName,
        Password,
        StaffID,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    )
    VALUES (
        @UserID,
        @UserName,
        @Password,
        @StaffID,
        @StaffNameEN,
        @StaffNameKH,
        @StaffPosition
    );
END;
Go

