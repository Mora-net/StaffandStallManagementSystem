Go
Create Table tbStaff
( 
   StaffID smallint Primary key Identity(1,1),
   StaffNameEN varchar(35),
   StaffNameKH nvarchar(35) Collate SQL_Latin1_General_CP850_Bin,
   Sex varchar(6),
   BirthDate date,
   StaffPosition varchar(50),
   PhoneNumber varchar(20),
   HouseNo varchar(30),
   StreetNo varchar(30),
   Province varchar(30),
   Sangkat varchar(30),
   Khann varchar(30),
   HiredDate date,
   Salary money,
   Photo varbinary(max),
   IsStopwork bit
)
Go 
Create Table tbStallType
(
  StallTypeID tinyint primary key,
  StallTypeName varchar(50),
  UnitPrice money
)
Go 
Create Table tbTenant
(
  TenantID int primary key Identity(1,1),
  FirstName varchar(50),
  LastName varchar(50),
  Sex Varchar(6),
  HouseNo varchar(20),
  StreetNo varchar(20),
  Sangkat varchar(100),
  Khann varchar(100),
  City varchar(100),
  PhoneNumber varchar(100)
)
Go 
Create Table tbStall
(
  StallNo smallint primary key, 
  StallTypeID tinyint ,
  Status bit,
  StallTypeName varchar(50);
  Foreign key(StallTypeID) References tbStallType(StallTypeID)
  on update cascade on delete no action
)





Create Table tbPayroll
(
  PayrollID  int primary key, 
  StaffID smallint,
  PayrollDate date,
  PaidAmount money,
  StaffNameEN varchar(35),
  StaffNameKH nvarchar(35) Collate SQL_Latin1_General_CP850_Bin,
  StaffPosition varchar(50),
  Foreign key(StaffID) References tbStaff(StaffID)
  on update cascade on delete no action
)
Go
Create Table tbUser(
   UserID smallint primary key,
   UserName Varchar(50),
   Password varchar(50),
   StaffID smallint,
   StaffNameEN varchar(35),
   StaffNameKH nvarchar(35) Collate SQL_Latin1_General_CP850_Bin,
   StaffPosition varchar(50),
   Foreign key(StaffID) References tbStaff(StaffID)
  on update cascade on delete no action
)
Go
Create Table tbRental(
     RentalNo int primary key,
	 RentalDate date,
	 PaidAmount money,
	 TenantID int,
	 StallNo smallint,
	 StaffID smallint,
	 StaffNameEN varchar(35),
	 StaffNameKH nvarchar(35) Collate SQL_Latin1_General_CP850_Bin,
     StaffPosition varchar(50),
	 Foreign key(StaffID) References tbStaff(StaffID)
     on update cascade on delete no action,
	 Foreign key(StallNo) References tbStall(StallNo)
	 on update cascade on delete no action,
	 Foreign key(TenantID) References tbTenant(TenantID)
     on update cascade on delete no action,
)
Go
Create Table tbRentalDetail(
    RentalNo int,
	StallNo smallint,
	RentalDate date,
	PaidAmount money,
	Foreign key(StallNo) References tbStall(StallNo),
	Foreign key(RentalNo) References tbRental(RentalNo),
	primary key(RentalNo,StallNo)
);

Go 
Create Table tbInvoive(
    InvoiceNo int primary key,
	InvoiceDate date,
	PaidAmount money,
	DataLine date,
	TenantID int,
	RentalNo int,
	StaffID smallint,
	StaffNameEN varchar(35),
	StaffNameKH nvarchar(35) Collate SQL_Latin1_General_CP850_Bin,
    StaffPosition varchar(50),
	FOREIGN KEY (StaffID) REFERENCES tbStaff(StaffID)
        ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (RentalNo) REFERENCES tbRental(RentalNo)
        ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (TenantID) REFERENCES tbTenant(TenantID)
        ON UPDATE NO ACTION ON DELETE NO ACTION
)
Go 
Create Table tbPayment(

      PaymentNo int primary key,
	  PaymentDate Date,
	  PaidAmount money , 
	  TenantID int,
	  RentalNo int,
	  StaffID smallint,
	  StaffNameEN varchar(35),
	  StaffNameKH nvarchar(35) Collate SQL_Latin1_General_CP850_Bin,
      StaffPosition varchar(50),
	  FOREIGN KEY (StaffID) REFERENCES tbStaff(StaffID)
        ON UPDATE NO ACTION ON DELETE NO ACTION,
     FOREIGN KEY (RentalNo) REFERENCES tbRental(RentalNo)
        ON UPDATE NO ACTION ON DELETE NO ACTION,
     FOREIGN KEY (TenantID) REFERENCES tbTenant(TenantID)
        ON UPDATE NO ACTION ON DELETE NO ACTION
)
Create Table tbLatePayment(
      LatePaymentNo int primary key,
	  LatePaymentDate Date,
	  PaidAmount money , 
	  TenantID int,
	  RentalNo int,
	  StaffID smallint,
	  StaffNameEN varchar(35),
	  StaffNameKH nvarchar(35) Collate SQL_Latin1_General_CP850_Bin,
      StaffPosition varchar(50),
	  FOREIGN KEY (StaffID) REFERENCES tbStaff(StaffID)
        ON UPDATE NO ACTION ON DELETE NO ACTION,
     FOREIGN KEY (RentalNo) REFERENCES tbRental(RentalNo)
        ON UPDATE NO ACTION ON DELETE NO ACTION,
     FOREIGN KEY (TenantID) REFERENCES tbTenant(TenantID)
        ON UPDATE NO ACTION ON DELETE NO ACTION
)
Go
Create Table tbPaymentDetail(
    PaymentNo int,
	InvoiceNo int ,
	InvoiceDate date,
	TotalAmount money,
	Foreign key(PaymentNo) References tbPayment(PaymentNo),
	Foreign key(InvoiceNo ) References tbInvoive(InvoiceNo ),
	primary key(PaymentNo,InvoiceNo )
);
Go
Create Table tbLatePaymentDetail(
    LatePaymentNo int,
	InvoiceNo int ,
	InvoiceDate date,
	TotalAmount money,
	Foreign key(LatePaymentNo) References tbLatePayment(LatePaymentNo),
	Foreign key(InvoiceNo ) References tbInvoive(InvoiceNo ),
	primary key(LatePaymentNo,InvoiceNo )
);

