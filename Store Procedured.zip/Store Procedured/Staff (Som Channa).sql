--- Staff Information ---
--- CountStaffRecord
CREATE PROCEDURE spCountStaffRecordsOut
    @Total INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT @Total = COUNT(*) FROM tbStaff;
END
Go
--- function SearchStaffByName
CREATE FUNCTION fnSearchStaffByName (@Name NVARCHAR(50))
RETURNS TABLE
AS
RETURN
(
    SELECT StaffID, StaffNameEN
    FROM tbStaff
    WHERE StaffNameEN LIKE  @Name + '%'
);
Go
--- UpdateStaffById
CREATE PROCEDURE sp_UpdateStafById
    @StaffID        SMALLINT,
    @StaffNameEN    VARCHAR(35),
    @StaffNameKH    NVARCHAR(35),
    @Sex            VARCHAR(6),
    @BirthDate      DATE,
    @StaffPosition  VARCHAR(50),
    @PhoneNumber    VARCHAR(20),
    @HouseNo        VARCHAR(30),
    @StreetNo       VARCHAR(30),
    @Province       VARCHAR(30),
    @Sangkat        VARCHAR(30),
    @Khann          VARCHAR(30),
    @HiredDate      DATE,
    @Salary         MONEY,
    @Photo          VARBINARY(MAX) = NULL,
    @IsStopwork     BIT
AS
BEGIN
    UPDATE tbStaff
    SET
        StaffNameEN    = @StaffNameEN,
        StaffNameKH    = @StaffNameKH,
        Sex            = @Sex,
        BirthDate      = @BirthDate,
        StaffPosition  = @StaffPosition,
        PhoneNumber    = @PhoneNumber,
        HouseNo        = @HouseNo,
        StreetNo       = @StreetNo,
        Province       = @Province,
        Sangkat        = @Sangkat,
        Khann          = @Khann,
        HiredDate      = @HiredDate,
        Salary         = @Salary,
        Photo          = CASE WHEN @Photo IS NOT NULL THEN @Photo ELSE Photo END,
        IsStopwork     = @IsStopwork
    WHERE StaffID = @StaffID;
END;
Go
--- View StaffList
CREATE VIEW vw_StaffList AS
SELECT 
    StaffID,
    StaffNameEN
FROM 
    tbStaff;
End
Go
--- GetStaffById
CREATE PROCEDURE sp_GetStaffById
    @id SmallInt
AS
BEGIN
    SELECT *
    FROM tbstaff
    WHERE StaffID = @id;
END
Go
--- InsertStaff
CREATE PROCEDURE spInsertStaff
    @StaffNameEN varchar(35),
    @StaffNameKH nvarchar(35),
    @Sex varchar(6),
    @BirthDate date,
    @StaffPosition varchar(50),
    @PhoneNumber varchar(20),
	@HouseNo varchar(30),
    @StreetNo varchar(30),
    @Province varchar(30),
    @Sangkat varchar(30),
	@Khann varchar(30),
    @HiredDate date,
    @Salary money,
    @Photo varbinary(max),
    @IsStopwork bit
AS
BEGIN
    INSERT INTO tbStaff(
        StaffNameEN, StaffNameKH, Sex,BirthDate, StaffPosition,
        PhoneNumber,HouseNo,StreetNo ,Province,Sangkat,Khann,
		HiredDate,Salary, Photo, IsStopwork
    )
    VALUES (
        @StaffNameEN, @StaffNameKH, @Sex, @BirthDate, @StaffPosition,
        @PhoneNumber,@HouseNo,@StreetNo,@Province ,@Sangkat,@Khann,@HiredDate,
		@Salary, @Photo,@IsStopwork
    )
END
Go






