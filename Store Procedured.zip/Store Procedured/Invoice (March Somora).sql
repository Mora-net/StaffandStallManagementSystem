--- Invoice's Information ---
--- View RentalPaid amount and Tenant
CREATE VIEW vw_RentalPaidAmountAndTenant
AS
SELECT 
    r.RentalNo,
    r.PaidAmount,
    r.TenantID,
    t.FirstName + ' '+ t.LastName As FullName 
FROM tbRental r
JOIN tbTenant t ON r.TenantID = t.TenantID;
End; 
Go
--- UpdateInvoice
CREATE PROCEDURE sp_UpdateInvoice
    @InvoiceNo INT,
    @InvoiceDate DATE,
    @PaidAmount MONEY,
    @DataLine DATE,
    @TenantID INT,
    @RentalNo INT,
    @StaffID SMALLINT,
    @StaffNameEN VARCHAR(35),
    @StaffNameKH NVARCHAR(35),
    @StaffPosition VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE tbInvoive
    SET
        InvoiceDate = @InvoiceDate,
        PaidAmount = @PaidAmount,
        DataLine = @DataLine,
        TenantID = @TenantID,
        RentalNo = @RentalNo,
        StaffID = @StaffID,
        StaffNameEN = @StaffNameEN,
        StaffNameKH = @StaffNameKH,
        StaffPosition = @StaffPosition
    WHERE InvoiceNo = @InvoiceNo;
END;
Go
--- InsertInvoice
CREATE PROCEDURE sp_InsertInvoice
    @InvoiceNo INT,
    @InvoiceDate DATE,
    @PaidAmount MONEY,
    @DataLine DATE,
    @TenantID INT,
    @RentalNo INT,
    @StaffID SMALLINT,
    @StaffNameEN VARCHAR(35),
    @StaffNameKH NVARCHAR(35),
    @StaffPosition VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO tbInvoive (
        InvoiceNo,
        InvoiceDate,
        PaidAmount,
        DataLine,
        TenantID,
        RentalNo,
        StaffID,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    )
    VALUES (
        @InvoiceNo,
        @InvoiceDate,
        @PaidAmount,
        @DataLine,
        @TenantID,
        @RentalNo,
        @StaffID,
        @StaffNameEN,
        @StaffNameKH,
        @StaffPosition
    );
END;
Go
--- Search InvoiceById
CREATE PROCEDURE sp_SearchInvoiceById
    @InvoiceNo INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        InvoiceNo,
        InvoiceDate,
        PaidAmount,
        DataLine,
        TenantID,
        RentalNo,
        StaffID,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    FROM tbInvoive
    WHERE InvoiceNo = @InvoiceNo;
END;
Go
--- Get InvoiceBy InvoiceAndRental
CREATE PROCEDURE sp_GetInvoiceByInvoiceAndRental
    @InvoiceNo INT,
    @RentalNo INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        InvoiceNo,
        InvoiceDate,
        PaidAmount,
        DataLine,
        TenantID,
        RentalNo,
        StaffID,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    FROM tbInvoive
    WHERE InvoiceNo = @InvoiceNo AND RentalNo = @RentalNo;
END;
Go




