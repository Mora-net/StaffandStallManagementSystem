CREATE PROCEDURE CheckUserLogin
    @UserName VARCHAR(50),
    @Password VARCHAR(50)
AS
BEGIN
    SELECT 
        UserID,
        UserName,
        StaffID,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    FROM tbUser
    WHERE 
        UserName = @UserName AND 
        Password = @Password;
END;
