--- LatePayment's Information ---
---  ViewInvoiceSummary
CREATE VIEW viwInvoiceSummary
AS
SELECT 
    i.InvoiceNo,
    i.InvoiceDate,
    i.PaidAmount,
    i.RentalNo,
    i.TenantID,
    t.FirstName + ' '+ t.LastName as FullName 
FROM tbInvoive i
JOIN tbTenant t ON i.TenantID = t.TenantID;
End 
Go
--- Count LatePayments
CREATE PROCEDURE sp_CountLatePayments
AS
BEGIN
    SET NOCOUNT ON;

    SELECT COUNT(*) AS TotalLatePayments
    FROM tbLatePayment;
END;
Go
--- Insert LatePayments
CREATE PROCEDURE spInsertLatePayment
    @LatePaymentNo INT,
    @LatePaymentDate DATE,
    @PaidAmount MONEY,
    @TenantID INT,
    @RentalNo INT,
    @InvoiceNo INT,
    @StaffID SMALLINT,
    @StaffNameEN VARCHAR(35),
    @StaffNameKH NVARCHAR(35),
    @StaffPosition VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO tbLatePayment
    (
        LatePaymentNo,
        LatePaymentDate,
        PaidAmount,
        TenantID,
        RentalNo,
        InvoiceNo,
        StaffID,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    )
    VALUES
    (
        @LatePaymentNo,
        @LatePaymentDate,
        @PaidAmount,
        @TenantID,
        @RentalNo,
        @InvoiceNo,
        @StaffID,
        @StaffNameEN,
        @StaffNameKH,
        @StaffPosition
    );
END;
Go
--- Insert LatePaymentDetail
CREATE PROCEDURE sppInsertLatePaymentDetail
    @LatePaymentNo INT,
    @InvoiceNo INT,
    @InvoiceDate DATE,
    @TotalAmount MONEY
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO tbLatePaymentDetail
    (
        LatePaymentNo,
        InvoiceNo,
        InvoiceDate,
        TotalAmount
    )
    VALUES
    (
        @LatePaymentNo,
        @InvoiceNo,
        @InvoiceDate,
        @TotalAmount
    );
END;
Go
--- GetLatePayment By LatePaymentNo and InvoiceNo
CREATE PROCEDURE spGetLatePaymentByLatePaymentNoAndInvoiceNo
    @LatePaymentNo INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        LatePaymentNo,
        LatePaymentDate,
        PaidAmount,
        TenantID,
        RentalNo,
        InvoiceNo,
        StaffID,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    FROM tbLatePayment
    WHERE LatePaymentNo = @LatePaymentNo ;
END;
Go
---- UpdateLatePayment By LatePaymentNo
ALTER 

CREATE PROCEDURE sp_UpdateLatePaymentByLatePaymentNo
    @LatePaymentNo INT,
    @LatePaymentDate DATE,
    @PaidAmount MONEY,
    @TenantID INT,
    @RentalNo INT,
    @InvoiceNo INT,
    @StaffID SMALLINT,
    @StaffNameEN VARCHAR(35),
    @StaffNameKH NVARCHAR(35),
    @StaffPosition VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE tbLatePayment
    SET 
        LatePaymentDate = @LatePaymentDate,
        PaidAmount = @PaidAmount,
        TenantID = @TenantID,
        RentalNo = @RentalNo,
        InvoiceNo = @InvoiceNo,
        StaffID = @StaffID,
        StaffNameEN = @StaffNameEN,
        StaffNameKH = @StaffNameKH,
        StaffPosition = @StaffPosition
    WHERE LatePaymentNo = @LatePaymentNo;
END;
Go
--- Update LatePaymentDetail By LatePaymentNo and InvoiceNo
CREATE PROCEDURE sp_UpdateLatePaymentDetailByLatePaymentNoAndInvoiceNo
    @LatePaymentNo INT,
    @InvoiceNo INT,
    @InvoiceDate DATE,
    @TotalAmount MONEY
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE tbLatePaymentDetail
    SET
        InvoiceDate = @InvoiceDate,
        TotalAmount = @TotalAmount
    WHERE LatePaymentNo = @LatePaymentNo AND InvoiceNo = @InvoiceNo;
END;
Go
