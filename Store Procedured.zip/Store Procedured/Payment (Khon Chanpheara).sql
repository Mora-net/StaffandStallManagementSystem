--- Payment's Information ---
--- view InvoiceSummary
CREATE VIEW viwInvoiceSummary
AS
SELECT 
    i.InvoiceNo,
    i.InvoiceDate,
    i.PaidAmount,
    i.RentalNo,
    i.TenantID,
    t.FirstName + ' '+ t.LastName as FullName 
FROM tbInvoive i
JOIN tbTenant t ON i.TenantID = t.TenantID;
End 
Go
--- Count Payments
CREATE PROCEDURE sp_CountPayments
AS
BEGIN
    SET NOCOUNT ON;

    SELECT COUNT(*) AS TotalPayments
    FROM tbPayment;
END;
Go
--- Insert Payment
CREATE PROCEDURE spInsertPayment
    @PaymentNo INT,
    @PaymentDate DATE,
    @PaidAmount MONEY,
    @TenantID INT,
    @RentalNo INT,
    @InvoiceNo INT,
    @StaffID SMALLINT,
    @StaffNameEN VARCHAR(35),
    @StaffNameKH NVARCHAR(35),
    @StaffPosition VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO tbPayment
    (
        PaymentNo,
        PaymentDate,
        PaidAmount,
        TenantID,
        RentalNo,
        InvoiceNo,
        StaffID,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    )
    VALUES
    (
        @PaymentNo,
        @PaymentDate,
        @PaidAmount,
        @TenantID,
        @RentalNo,
        @InvoiceNo,
        @StaffID,
        @StaffNameEN,
        @StaffNameKH,
        @StaffPosition
    );
END;
Go
--- InsertPaymentDetail
CREATE PROCEDURE sppInsertPaymentDetail
    @PaymentNo INT,
    @InvoiceNo INT,
    @InvoiceDate DATE,
    @TotalAmount MONEY
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO tbPaymentDetail
    (
        PaymentNo,
        InvoiceNo,
        InvoiceDate,
        TotalAmount
    )
    VALUES
    (
        @PaymentNo,
        @InvoiceNo,
        @InvoiceDate,
        @TotalAmount
    );
END;
Go
--- GetPayment by PaymentNo and InvoiceNO
CREATE PROCEDURE spGetPaymentByPaymentNoAndInvoiceNo
    @PaymentNo INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        PaymentNo,
        PaymentDate,
        PaidAmount,
        TenantID,
        RentalNo,
        InvoiceNo,
        StaffID,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    FROM tbPayment
    WHERE PaymentNo = @PaymentNo ;
END;
Go
--- UpdatePayment By PaymentNo
ALTER 

CREATE PROCEDURE sp_UpdatePaymentByPaymentNo
    @PaymentNo INT,
    @PaymentDate DATE,
    @PaidAmount MONEY,
    @TenantID INT,
    @RentalNo INT,
    @InvoiceNo INT,
    @StaffID SMALLINT,
    @StaffNameEN VARCHAR(35),
    @StaffNameKH NVARCHAR(35),
    @StaffPosition VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE tbPayment
    SET 
        PaymentDate = @PaymentDate,
        PaidAmount = @PaidAmount,
        TenantID = @TenantID,
        RentalNo = @RentalNo,
        InvoiceNo = @InvoiceNo,
        StaffID = @StaffID,
        StaffNameEN = @StaffNameEN,
        StaffNameKH = @StaffNameKH,
        StaffPosition = @StaffPosition
    WHERE PaymentNo = @PaymentNo;
END;
Go
--- UpdatePaymentDetail By PaymentNo and InvoiceNo

CREATE PROCEDURE sp_UpdatePaymentDetailByPaymentNoAndInvoiceNo
    @PaymentNo INT,
    @InvoiceNo INT,
    @InvoiceDate DATE,
    @TotalAmount MONEY
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE tbPaymentDetail
    SET
        InvoiceDate = @InvoiceDate,
        TotalAmount = @TotalAmount
    WHERE PaymentNo = @PaymentNo AND InvoiceNo = @InvoiceNo;
END;
Go
