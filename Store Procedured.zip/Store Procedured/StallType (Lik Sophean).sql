--- StallType Information ---
--- function SearchStafllTypeByName
CREATE FUNCTION fn_SearchStallTypeByName
(
    @SearchName VARCHAR(50)
)
RETURNS TABLE
AS
RETURN
(
    SELECT 
        StallTypeID, 
        StallTypeName, 
        UnitPrice
    FROM 
        tbStallType
    WHERE 
        StallTypeName LIKE  @SearchName + '%'
);
END
Go
--- Get StallType By Id
CREATE PROCEDURE GetStallTypeById
    @Id tinyint
AS
BEGIN
    SELECT * FROM tbStallType WHERE StallTypeID = @Id;
END
Go
--- Count StallTypes
CREATE PROCEDURE sp_CountStallTypes
AS
BEGIN
  SELECT COUNT(*) AS TotalStallTypes FROM tbStallType;
END;
Go



