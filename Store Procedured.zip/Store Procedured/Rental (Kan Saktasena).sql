--- Rental's Information ---
--- Update Rental
CREATE PROCEDURE sp_UpdateRental
    @RentalNo INT,
    @RentalDate DATE,
    @PaidAmount MONEY,
    @TenantID INT,
    @StallNo SMALLINT,
    @StaffID SMALLINT,
    @StaffNameEN VARCHAR(35),
    @StaffNameKH NVARCHAR(35),
    @StaffPosition VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE tbRental
    SET
        RentalDate = @RentalDate,
        PaidAmount = @PaidAmount,
        TenantID = @TenantID,
        StallNo = @StallNo,
        StaffID = @StaffID,
        StaffNameEN = @StaffNameEN,
        StaffNameKH = @StaffNameKH,
        StaffPosition = @StaffPosition
    WHERE RentalNo = @RentalNo;
END;
GO
--- Update RentalDetail
CREATE PROCEDURE sp_UpdateRentalDetail
(
    @RentalNo INT,
    @StallNo SMALLINT,
    @RentalDate DATE,
    @PaidAmount MONEY
)
AS
BEGIN
    SET NOCOUNT ON;

    -- Update the record if it exists
    UPDATE tbRentalDetail
    SET
        RentalDate = @RentalDate,
        PaidAmount = @PaidAmount
    WHERE RentalNo = @RentalNo AND StallNo = @StallNo;

    -- Optionally, you can check if the update affected any rows,
    -- and if not, you may want to insert instead (upsert logic).
    
    IF @@ROWCOUNT = 0
    BEGIN
        -- Insert new record if not exists
        INSERT INTO tbRentalDetail (RentalNo, StallNo, RentalDate, PaidAmount)
        VALUES (@RentalNo, @StallNo, @RentalDate, @PaidAmount);
    END
END;
Go
--- Get RentalByRental and Stall
CREATE PROCEDURE sp_GetRentalByRentalAndStall
    @RentalNo INT,
    @StallNo SMALLINT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        RentalNo,
        RentalDate,
        PaidAmount,
        TenantID,
        StallNo,
        StaffID,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    FROM tbRental
    WHERE RentalNo = @RentalNo AND StallNo = @StallNo;
END;
Go
--- Get RentalDetail by RentalAndStall
CREATE PROCEDURE sp_GetRentalDetailByRentalAndStall
    @RentalNo INT,
    @StallNo SMALLINT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        rd.RentalNo,
        rd.StallNo,
        rd.RentalDate,
        rd.PaidAmount
    FROM tbRentalDetail rd
    WHERE rd.RentalNo = @RentalNo AND rd.StallNo = @StallNo;
END
Go
--- Insert Rental
CREATE PROCEDURE sp_InsertRental
    @RentalNo INT,
    @RentalDate DATE,
    @PaidAmount MONEY,
    @TenantID INT,
    @StallNo SMALLINT,
    @StaffID SMALLINT,
    @StaffNameEN VARCHAR(35),
    @StaffNameKH NVARCHAR(35),
    @StaffPosition VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO tbRental (
        RentalNo,
        RentalDate,
        PaidAmount,
        TenantID,
        StallNo,
        StaffID,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    )
    VALUES (
        @RentalNo,
        @RentalDate,
        @PaidAmount,
        @TenantID,
        @StallNo,
        @StaffID,
        @StaffNameEN,
        @StaffNameKH,
        @StaffPosition
    );
END;
GO
--- Insert RentalDetail
CREATE PROCEDURE sp_InsertRentalDetail
    @RentalNo INT,
    @StallNo SMALLINT,
    @RentalDate DATE,
    @PaidAmount MONEY
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO tbRentalDetail (RentalNo, StallNo, RentalDate, PaidAmount)
    VALUES (@RentalNo, @StallNo, @RentalDate, @PaidAmount);
END;
GO
--- Search RentalByID
CREATE PROCEDURE sp_SearchRentalById
    @RentalNo INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        RentalNo,
        RentalDate,
        PaidAmount,
        TenantID,
        StallNo,
        StaffID,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    FROM tbRental
    WHERE RentalNo = @RentalNo;
END;
Go
--- Count Rental
CREATE PROCEDURE sp_CountRental
AS
BEGIN
    SET NOCOUNT ON;

    SELECT COUNT(*) AS TotalRentals
    FROM tbRental;
END;
GO









