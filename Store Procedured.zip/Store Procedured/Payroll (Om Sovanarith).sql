--- Payroll's Information ---
--- function Search PayrollByName
CREATE FUNCTION fn_SearchPayrollByName (@Name NVARCHAR(100))
RETURNS TABLE
AS
RETURN
(
    SELECT 
        PayrollID,
        StaffID,
        PayrollDate,
        PaidAmount,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    FROM tbPayroll
    WHERE StaffNameEN LIKE @Name + '%'
);
End
Go
--- UpdatePayroll
CREATE PROCEDURE sp_UpdatePayroll
    @PayrollID INT,
    @StaffID SMALLINT,
    @PayrollDate DATE,
    @PaidAmount MONEY,
    @StaffNameEN VARCHAR(35),
    @StaffNameKH NVARCHAR(35),
    @StaffPosition VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE tbPayroll
    SET
        StaffID = @StaffID,
        PayrollDate = @PayrollDate,
        PaidAmount = @PaidAmount,
        StaffNameEN = @StaffNameEN,
        StaffNameKH = @StaffNameKH,
        StaffPosition = @StaffPosition
    WHERE PayrollID = @PayrollID;
END;
Go
--- InsertPayroll
CREATE PROCEDURE sp_InsertPayroll
    @PayrollID INT,
    @StaffID SMALLINT,
    @PayrollDate DATE,
    @PaidAmount MONEY,
    @StaffNameEN VARCHAR(35),
    @StaffNameKH NVARCHAR(35),
    @StaffPosition VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO tbPayroll (
        PayrollID,
        StaffID,
        PayrollDate,
        PaidAmount,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    )
    VALUES (
        @PayrollID,
        @StaffID,
        @PayrollDate,
        @PaidAmount,
        @StaffNameEN,
        @StaffNameKH,
        @StaffPosition
    );
END;
Go
--- Count Payroll
CREATE PROCEDURE sp_CountPayroll
AS
BEGIN
    SET NOCOUNT ON;

    SELECT COUNT(*) AS TotalPayrollCount
    FROM tbPayroll;
END;
Go
--- Get PayrollById
CREATE PROCEDURE sp_GetPayrollById
    @PayrollID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        PayrollID,
        StaffID,
        PayrollDate,
        PaidAmount,
        StaffNameEN,
        StaffNameKH,
        StaffPosition
    FROM tbPayroll
    WHERE PayrollID = @PayrollID;
END;
Go





